SDL_Texture* charger_image(const char* nomFichier, SDL_Renderer* renderer);

//SDL_Texture charger_image_transparente(const char* nomfichier, SDL_Renderer* renderer, Uint8 r, Uint8 g, Uint8 b);
