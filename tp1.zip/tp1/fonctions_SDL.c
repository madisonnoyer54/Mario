#include <SDL2/SDL.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>



SDL_Texture* charger_image(const char* nomFichier, SDL_Renderer* renderer){
	SDL_Surface* surface = SDL_LoadBMP(nomFichier);
	SDL_Texture* image = SDL_CreateTextureFromSurface(renderer, surface);
	SDL_FreeSurface(surface);
	return image;
}


